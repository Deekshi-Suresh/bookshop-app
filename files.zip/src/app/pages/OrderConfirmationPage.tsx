import { useLocation, useNavigate } from 'react-router';
import { Header } from '../components/Header';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { CheckCircle, Package, Truck, MapPin } from 'lucide-react';
import { formatINR } from '../lib/currency';

interface Order {
  id: string;
  date: string;
  items: any[];
  totalAmount: number;
  priceINR: number;
  taxINR: number;
  customerName: string;
  customerEmail: string;
  shippingAddress: string;
  paymentMethod: string;
  status: string;
  estimatedDelivery: string;
}

export function OrderConfirmationPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const order: Order | undefined = location.state?.order;

  if (!order) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-8 text-center">
          <p className="text-gray-600 mb-4">Order not found</p>
          <Button onClick={() => navigate('/dashboard')}>Back to Shopping</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Success Message */}
        <div className="text-center mb-12">
          <CheckCircle className="h-20 w-20 text-green-500 mx-auto mb-4" />
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Order Confirmed!</h1>
          <p className="text-gray-600 text-lg">
            Thank you for your purchase. Your order has been successfully placed.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Order Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Order Info Card */}
            <Card>
              <CardHeader>
                <CardTitle>Order Information</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 gap-6">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Order Number</p>
                  <p className="text-xl font-bold text-blue-600">{order.id}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Order Date</p>
                  <p className="text-lg font-semibold">{order.date}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Estimated Delivery</p>
                  <p className="text-lg font-semibold">{order.estimatedDelivery}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Payment Method</p>
                  <p className="text-lg font-semibold">{order.paymentMethod}</p>
                </div>
              </CardContent>
            </Card>

            {/* Shipping Address */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  Shipping Address
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-semibold mb-1">{order.customerName}</p>
                <p className="text-gray-700 whitespace-pre-line">{order.shippingAddress}</p>
                <p className="text-gray-600 text-sm mt-2">{order.customerEmail}</p>
              </CardContent>
            </Card>

            {/* Order Items */}
            <Card>
              <CardHeader>
                <CardTitle>Order Items</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {order.items.map((item, index) => (
                    <div key={index} className="flex gap-4 pb-4 border-b last:border-b-0">
                      <img
                        src={item.book.image}
                        alt={item.book.title}
                        className="w-16 h-24 object-cover rounded"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold">{item.book.title}</h3>
                        <p className="text-sm text-gray-600">{item.book.author}</p>
                        <div className="mt-2 flex justify-between">
                          <p className="text-sm">
                            Quantity: <span className="font-semibold">{item.quantity}</span>
                          </p>
                          <p className="font-semibold">
                            ₹{formatINR(item.book.price * item.quantity * 83)}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Timeline */}
            <Card>
              <CardHeader>
                <CardTitle>Delivery Timeline</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <CheckCircle className="h-6 w-6 text-green-500 mb-2" />
                      <div className="w-0.5 h-12 bg-green-500"></div>
                    </div>
                    <div className="pb-8">
                      <p className="font-semibold text-green-600">Order Confirmed</p>
                      <p className="text-sm text-gray-600">Today</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <Package className="h-6 w-6 text-blue-500 mb-2" />
                      <div className="w-0.5 h-12 bg-gray-300"></div>
                    </div>
                    <div className="pb-8">
                      <p className="font-semibold">Processing & Packing</p>
                      <p className="text-sm text-gray-600">1-2 business days</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <Truck className="h-6 w-6 text-blue-500" />
                    </div>
                    <div>
                      <p className="font-semibold">Out for Delivery</p>
                      <p className="text-sm text-gray-600">
                        Expected: {order.estimatedDelivery}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Summary Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-20">
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2 pb-4 border-b">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>₹{formatINR(order.priceINR)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tax (10%)</span>
                    <span>₹{formatINR(order.taxINR)}</span>
                  </div>
                  <div className="flex justify-between text-green-600">
                    <span>Shipping</span>
                    <span>FREE</span>
                  </div>
                </div>

                <div className="flex justify-between text-xl font-bold">
                  <span>Total Amount</span>
                  <span className="text-blue-600">₹{formatINR(order.totalAmount)}</span>
                </div>

                <div className="bg-green-50 border border-green-200 rounded-lg p-3 mt-4">
                  <p className="text-xs text-green-800 mb-2">
                    ✓ Order confirmation sent to {order.customerEmail}
                  </p>
                  <p className="text-xs text-green-800">
                    ✓ You will receive shipping updates via email and SMS
                  </p>
                </div>

                <div className="space-y-2">
                  <Button
                    onClick={() => navigate('/dashboard')}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                  >
                    Continue Shopping
                  </Button>
                  <Button
                    onClick={() => navigate('/wishlist')}
                    variant="outline"
                    className="w-full"
                  >
                    View Wishlist
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}