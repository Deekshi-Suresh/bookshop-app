import { Link, useNavigate } from 'react-router';
import { Header } from '../components/Header';
import { useCart } from '../contexts/CartContext';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Trash2, ShoppingBag, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { formatINR, convertToINR } from '../lib/currency';

export function CartPage() {
  const { items, removeFromCart, updateQuantity, totalPrice, clearCart } = useCart();
  const navigate = useNavigate();

  const totalINR = convertToINR(totalPrice);
  const taxINR = Math.round(totalINR * 0.1);
  const grandTotalINR = totalINR + taxINR;

  const handleCheckout = () => {
    if (items.length === 0) {
      toast.error('Your cart is empty');
      return;
    }
    navigate('/checkout');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Link to="/dashboard" className="flex items-center gap-2 text-blue-600 hover:text-blue-700 mb-4">
            <ArrowLeft className="h-4 w-4" />
            Back to Shopping
          </Link>
          <h1 className="text-4xl font-bold text-gray-900">Shopping Cart</h1>
        </div>

        {items.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {items.map(item => (
                <Card key={item.book.id} className="overflow-hidden">
                  <CardContent className="p-6">
                    <div className="flex gap-4">
                      {/* Book Image */}
                      <div className="w-24 h-32 flex-shrink-0">
                        <img
                          src={item.book.image}
                          alt={item.book.title}
                          className="w-full h-full object-cover rounded"
                        />
                      </div>

                      {/* Book Details */}
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg mb-1">{item.book.title}</h3>
                        <p className="text-gray-600 text-sm mb-3">{item.book.author}</p>

                        <div className="flex items-center justify-between">
                          <div className="text-2xl font-bold text-blue-600">
                            ₹{formatINR(convertToINR(item.book.price) * item.quantity)}
                          </div>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() =>
                                updateQuantity(item.book.id, item.quantity - 1)
                              }
                              className="px-3 py-1 bg-gray-200 hover:bg-gray-300 rounded"
                            >
                              −
                            </button>
                            <input
                              type="number"
                              min="1"
                              value={item.quantity}
                              onChange={(e) =>
                                updateQuantity(
                                  item.book.id,
                                  parseInt(e.target.value) || 1
                                )
                              }
                              className="w-16 text-center border border-gray-300 rounded py-1"
                            />
                            <button
                              onClick={() =>
                                updateQuantity(item.book.id, item.quantity + 1)
                              }
                              className="px-3 py-1 bg-gray-200 hover:bg-gray-300 rounded"
                            >
                              +
                            </button>
                          </div>
                          <button
                            onClick={() => {
                              removeFromCart(item.book.id);
                              toast.success(`"${item.book.title}" removed from cart`);
                            }}
                            className="p-2 text-red-600 hover:bg-red-50 rounded"
                          >
                            <Trash2 className="h-5 w-5" />
                          </button>
                        </div>

                        <p className="text-xs text-gray-500 mt-2">
                          Unit price: ₹{formatINR(convertToINR(item.book.price))}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <Card className="sticky top-20">
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2 pb-4 border-b">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span className="font-semibold">₹{formatINR(totalINR)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Shipping:</span>
                      <span className="font-semibold text-green-600">FREE</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Tax (10%):</span>
                      <span className="font-semibold">₹{formatINR(taxINR)}</span>
                    </div>
                  </div>

                  <div className="flex justify-between text-lg font-bold">
                    <span>Total:</span>
                    <span className="text-blue-600">₹{formatINR(grandTotalINR)}</span>
                  </div>

                  <div className="space-y-2">
                    <Button
                      onClick={handleCheckout}
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3"
                    >
                      Proceed to Checkout
                    </Button>
                    <Button
                      onClick={() => navigate('/dashboard')}
                      variant="outline"
                      className="w-full"
                    >
                      Continue Shopping
                    </Button>
                    <Button
                      onClick={() => {
                        clearCart();
                        toast.success('Cart cleared');
                      }}
                      variant="ghost"
                      className="w-full text-red-600 hover:text-red-700"
                    >
                      Clear Cart
                    </Button>
                  </div>

                  <div className="bg-blue-50 p-3 rounded text-xs text-blue-900">
                    ✓ Free shipping on all orders
                    <br />✓ Easy returns within 30 days
                    <br />✓ Secure checkout
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        ) : (
          <div className="text-center py-16">
            <ShoppingBag className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h2 className="text-2xl font-semibold text-gray-900 mb-2">Your cart is empty</h2>
            <p className="text-gray-600 mb-6">
              Start shopping to add books to your cart
            </p>
            <Link to="/dashboard">
              <Button className="bg-blue-600 hover:bg-blue-700">
                Start Shopping
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}