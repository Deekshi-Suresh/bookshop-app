import { useState, useEffect } from 'react';
import { Link } from 'react-router';
import { Header } from '../components/Header';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { BookCard } from '../components/BookCard';
import { Heart, ArrowLeft, Trash2, ShoppingBag } from 'lucide-react';
import { books } from '../data/books';
import { toast } from 'sonner';

export function WishlistPage() {
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    const saved = localStorage.getItem('bookshop_wishlist');
    if (saved) {
      setWishlist(JSON.parse(saved));
    }
  }, []);

  useEffect(() => {
    if (isMounted) {
      localStorage.setItem('bookshop_wishlist', JSON.stringify(wishlist));
    }
  }, [wishlist, isMounted]);

  const wishlistBooks = books.filter(b => wishlist.includes(b.id));

  const removeFromWishlist = (bookId: string) => {
    setWishlist(prev => prev.filter(id => id !== bookId));
    toast.success('Removed from wishlist');
  };

  const addAllToCart = () => {
    const { useCart } = require('../contexts/CartContext');
    // This is handled by individual BookCard components
    toast.success('Added all items from wishlist to cart');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Link to="/dashboard" className="flex items-center gap-2 text-blue-600 hover:text-blue-700 mb-4">
            <ArrowLeft className="h-4 w-4" />
            Back to Shopping
          </Link>
          <h1 className="text-4xl font-bold text-gray-900 flex items-center gap-2">
            <Heart className="h-8 w-8 text-red-500 fill-red-500" />
            My Wishlist
          </h1>
          <p className="text-gray-600 mt-2">
            {wishlistBooks.length} {wishlistBooks.length === 1 ? 'book' : 'books'} in your wishlist
          </p>
        </div>

        {wishlistBooks.length > 0 ? (
          <div className="space-y-6">
            {/* Add All to Cart Button */}
            <Button
              onClick={addAllToCart}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <ShoppingBag className="h-4 w-4 mr-2" />
              Add All to Cart
            </Button>

            {/* Books Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {wishlistBooks.map(book => (
                <div key={book.id} className="relative">
                  <BookCard book={book} />
                  <button
                    onClick={() => removeFromWishlist(book.id)}
                    className="absolute top-4 right-4 bg-red-500 hover:bg-red-600 text-white rounded-full p-2 shadow-lg transition-colors z-10"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <Card className="border-0 shadow-lg">
            <CardContent className="p-12 text-center">
              <Heart className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h2 className="text-2xl font-semibold text-gray-900 mb-2">Your wishlist is empty</h2>
              <p className="text-gray-600 mb-6">
                Add books to your wishlist to save them for later
              </p>
              <Link to="/dashboard">
                <Button className="bg-blue-600 hover:bg-blue-700">
                  Start Shopping
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}