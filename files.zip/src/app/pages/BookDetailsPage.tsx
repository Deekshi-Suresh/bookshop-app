import { useParams, useNavigate, Link } from 'react-router';
import { useState } from 'react';
import { Header } from '../components/Header';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { ReviewsSection } from '../components/ReviewsSection';
import { useCart } from '../contexts/CartContext';
import { useReview } from '../contexts/ReviewContext';
import { books } from '../data/books';
import { ArrowLeft, ShoppingCart, Heart, Star } from 'lucide-react';
import { toast } from 'sonner';
import { formatINR, convertToINR } from '../lib/currency';

export function BookDetailsPage() {
  const { bookId } = useParams<{ bookId: string }>();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { getAverageRating, getReviewCount } = useReview();
  const [isInWishlist, setIsInWishlist] = useState(false);

  const book = books.find(b => b.id === bookId);

  if (!book) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-8 text-center">
          <p className="text-gray-600 mb-4">Book not found</p>
          <Button onClick={() => navigate('/dashboard')}>Back to Shopping</Button>
        </div>
      </div>
    );
  }

  const reviewCount = getReviewCount(book.id);
  const avgRating = getAverageRating(book.id) || book.rating;
  const priceINR = convertToINR(book.price);

  const handleAddToCart = () => {
    addToCart(book);
    toast.success(`"${book.title}" added to cart`);
  };

  const handleWishlist = () => {
    const wishlist = JSON.parse(localStorage.getItem('bookshop_wishlist') || '[]');
    if (isInWishlist) {
      const updated = wishlist.filter((id: string) => id !== book.id);
      localStorage.setItem('bookshop_wishlist', JSON.stringify(updated));
      setIsInWishlist(false);
      toast.success('Removed from wishlist');
    } else {
      wishlist.push(book.id);
      localStorage.setItem('bookshop_wishlist', JSON.stringify(wishlist));
      setIsInWishlist(true);
      toast.success('Added to wishlist');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Back Button */}
        <button
          onClick={() => navigate('/dashboard')}
          className="flex items-center gap-2 text-blue-600 hover:text-blue-700 mb-8"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Books
        </button>

        {/* Book Details */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {/* Book Image */}
          <div>
            <img
              src={book.image}
              alt={book.title}
              className="w-full rounded-lg shadow-lg"
            />
          </div>

          {/* Book Info */}
          <div className="md:col-span-2">
            <div className="mb-4">
              <span className="inline-block px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-semibold mb-3">
                {book.category}
              </span>
            </div>

            <h1 className="text-4xl font-bold text-gray-900 mb-2">{book.title}</h1>
            <p className="text-xl text-gray-600 mb-4">{book.author}</p>

            {/* Rating */}
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map(star => (
                  <Star
                    key={star}
                    className={`h-5 w-5 ${
                      star <= Math.round(avgRating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <span className="text-lg font-semibold">{avgRating} out of 5</span>
              <span className="text-gray-600">({reviewCount} reviews)</span>
            </div>

            {/* Description */}
            <p className="text-gray-700 mb-6 leading-relaxed text-lg">
              {book.description}
            </p>

            {/* Price and Stock */}
            <div className="bg-white rounded-lg p-6 shadow-md mb-6">
              <div className="text-4xl font-bold text-blue-600 mb-2">
                ₹{formatINR(priceINR)}
              </div>
              <div className="flex items-center gap-2 mb-4">
                {book.inStock ? (
                  <span className="text-green-600 font-semibold">✓ In Stock</span>
                ) : (
                  <span className="text-red-600 font-semibold">Out of Stock</span>
                )}
              </div>

              {/* Action Buttons */}
              <div className="space-y-3">
                <Button
                  onClick={handleAddToCart}
                  disabled={!book.inStock}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 text-lg"
                >
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  Add to Cart
                </Button>
                <Button
                  onClick={handleWishlist}
                  variant="outline"
                  className="w-full"
                >
                  <Heart className={`h-5 w-5 mr-2 ${isInWishlist ? 'fill-red-500 text-red-500' : ''}`} />
                  {isInWishlist ? 'Remove from Wishlist' : 'Add to Wishlist'}
                </Button>
              </div>
            </div>

            {/* Book Info */}
            <Card>
              <CardContent className="pt-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">Format</p>
                    <p className="font-semibold">Paperback</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Pages</p>
                    <p className="font-semibold">~300-400</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Publisher</p>
                    <p className="font-semibold">Various</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Language</p>
                    <p className="font-semibold">English</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Reviews Section */}
        <ReviewsSection bookId={book.id} bookTitle={book.title} />
      </div>
    </div>
  );
}