import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useCart } from '../contexts/CartContext';
import { Header } from '../components/Header';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { PaymentMethods } from '../components/PaymentMethods';
import { ArrowLeft, Loader2, Lock } from 'lucide-react';
import { toast } from 'sonner';
import { formatINR, convertToINR } from '../lib/currency';

export function CheckoutPage() {
  const navigate = useNavigate();
  const { items, totalPrice, clearCart } = useCart();
  const [loading, setLoading] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [step, setStep] = useState<'shipping' | 'payment'>('shipping');

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    upiId: '',
  });

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-8 text-center">
          <p className="text-gray-600 mb-4">Your cart is empty</p>
          <Button onClick={() => navigate('/dashboard')}>Back to Shopping</Button>
        </div>
      </div>
    );
  }

  const priceINR = convertToINR(totalPrice);
  const taxINR = Math.round(priceINR * 0.1);
  const totalINR = priceINR + taxINR;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const validateShippingForm = () => {
    if (!formData.firstName.trim()) {
      toast.error('First name is required');
      return false;
    }
    if (!formData.lastName.trim()) {
      toast.error('Last name is required');
      return false;
    }
    if (!formData.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      toast.error('Valid email is required');
      return false;
    }
    if (!formData.phone.match(/^\d{10}$/)) {
      toast.error('Valid 10-digit phone number is required');
      return false;
    }
    if (!formData.address.trim()) {
      toast.error('Address is required');
      return false;
    }
    if (!formData.city.trim()) {
      toast.error('City is required');
      return false;
    }
    if (!formData.state.trim()) {
      toast.error('State is required');
      return false;
    }
    if (!formData.zipCode.match(/^\d{6}$/)) {
      toast.error('Valid 6-digit PIN code is required');
      return false;
    }
    return true;
  };

  const validatePaymentForm = () => {
    if (paymentMethod === 'card') {
      if (!formData.cardNumber.match(/^\d{16}$/)) {
        toast.error('Valid 16-digit card number is required');
        return false;
      }
      if (!formData.expiryDate.match(/^\d{2}\/\d{2}$/)) {
        toast.error('Expiry date must be MM/YY format');
        return false;
      }
      if (!formData.cvv.match(/^\d{3}$/)) {
        toast.error('Valid 3-digit CVV is required');
        return false;
      }
    } else if (paymentMethod === 'upi') {
      if (!formData.upiId.match(/^[a-zA-Z0-9._-]+@[a-zA-Z]+$/)) {
        toast.error('Valid UPI ID is required (e.g., yourname@upi)');
        return false;
      }
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (step === 'shipping') {
      if (!validateShippingForm()) return;
      setStep('payment');
      return;
    }

    if (!validatePaymentForm()) return;

    setLoading(true);

    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));

    const paymentMethodNames: Record<string, string> = {
      card: 'Credit Card',
      upi: 'UPI',
      wallet: 'Digital Wallet',
      cod: 'Cash on Delivery',
    };

    const order = {
      id: `ORD-${Date.now()}`,
      date: new Date().toLocaleDateString('en-IN'),
      items,
      totalAmount: totalINR,
      priceINR,
      taxINR,
      customerName: `${formData.firstName} ${formData.lastName}`,
      customerEmail: formData.email,
      shippingAddress: `${formData.address}, ${formData.city}, ${formData.state} ${formData.zipCode}`,
      paymentMethod: paymentMethodNames[paymentMethod],
      status: 'Confirmed',
      estimatedDelivery: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
    };

    const orders = JSON.parse(localStorage.getItem('bookshop_orders') || '[]');
    orders.push(order);
    localStorage.setItem('bookshop_orders', JSON.stringify(orders));

    clearCart();
    toast.success('Order placed successfully!');
    setLoading(false);
    navigate('/order-confirmation', { state: { order } });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <button
          onClick={() => {
            if (step === 'payment') {
              setStep('shipping');
            } else {
              navigate('/cart');
            }
          }}
          className="flex items-center gap-2 text-blue-600 hover:text-blue-700 mb-8"
        >
          <ArrowLeft className="h-4 w-4" />
          {step === 'payment' ? 'Back to Shipping' : 'Back to Cart'}
        </button>

        <h1 className="text-4xl font-bold text-gray-900 mb-8">
          {step === 'shipping' ? 'Shipping Information' : 'Payment Details'}
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Form */}
          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Shipping Step */}
              {step === 'shipping' && (
                <Card>
                  <CardHeader>
                    <CardTitle>Shipping Address</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <input
                        type="text"
                        name="firstName"
                        placeholder="First Name"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                      <input
                        type="text"
                        name="lastName"
                        placeholder="Last Name"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>

                    <input
                      type="email"
                      name="email"
                      placeholder="Email Address"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />

                    <input
                      type="tel"
                      name="phone"
                      placeholder="Phone Number (10 digits)"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />

                    <input
                      type="text"
                      name="address"
                      placeholder="Street Address"
                      value={formData.address}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />

                    <div className="grid grid-cols-2 gap-4">
                      <input
                        type="text"
                        name="city"
                        placeholder="City"
                        value={formData.city}
                        onChange={handleInputChange}
                        className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                      <input
                        type="text"
                        name="state"
                        placeholder="State"
                        value={formData.state}
                        onChange={handleInputChange}
                        className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>

                    <input
                      type="text"
                      name="zipCode"
                      placeholder="PIN Code (6 digits)"
                      value={formData.zipCode}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />

                    <Button
                      type="submit"
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3"
                    >
                      Continue to Payment
                    </Button>
                  </CardContent>
                </Card>
              )}

              {/* Payment Step */}
              {step === 'payment' && (
                <>
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Lock className="h-5 w-5" />
                        Select Payment Method
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <PaymentMethods
                        selectedMethod={paymentMethod}
                        onSelect={setPaymentMethod}
                      />
                    </CardContent>
                  </Card>

                  {/* Payment Form Based on Method */}
                  {paymentMethod === 'card' && (
                    <Card>
                      <CardHeader>
                        <CardTitle>Card Details</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <input
                          type="text"
                          name="cardNumber"
                          placeholder="Card Number (16 digits)"
                          value={formData.cardNumber}
                          onChange={handleInputChange}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          required
                        />

                        <div className="grid grid-cols-2 gap-4">
                          <input
                            type="text"
                            name="expiryDate"
                            placeholder="MM/YY"
                            value={formData.expiryDate}
                            onChange={handleInputChange}
                            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required
                          />
                          <input
                            type="text"
                            name="cvv"
                            placeholder="CVV (3 digits)"
                            value={formData.cvv}
                            onChange={handleInputChange}
                            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required
                          />
                        </div>

                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                          <p className="text-xs text-blue-800">
                            💳 <strong>Test Card:</strong> 4532 1111 1111 1111 | MM/YY: Any future date | CVV: Any 3 digits
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {paymentMethod === 'upi' && (
                    <Card>
                      <CardHeader>
                        <CardTitle>UPI Payment</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <input
                          type="text"
                          name="upiId"
                          placeholder="UPI ID (e.g., yourname@upi)"
                          value={formData.upiId}
                          onChange={handleInputChange}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          required
                        />
                        <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                          <p className="text-xs text-green-800">
                            ✓ Supports Google Pay, PhonePe, BHIM, and all major UPI apps
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {paymentMethod === 'cod' && (
                    <Card>
                      <CardHeader>
                        <CardTitle>Cash on Delivery</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-700">
                          Pay ₹{formatINR(totalINR)} when you receive your order. Our delivery partner will collect the payment.
                        </p>
                      </CardContent>
                    </Card>
                  )}

                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 text-lg"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                        Processing Payment...
                      </>
                    ) : (
                      `Pay ₹${formatINR(totalINR)}`
                    )}
                  </Button>
                </>
              )}
            </form>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <Card className="sticky top-20">
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {items.map(item => (
                    <div key={item.book.id} className="flex justify-between text-sm">
                      <div>
                        <p className="font-semibold line-clamp-1">{item.book.title}</p>
                        <p className="text-gray-600">Qty: {item.quantity}</p>
                      </div>
                      <p className="font-semibold">
                        ₹{formatINR(convertToINR(item.book.price * item.quantity))}
                      </p>
                    </div>
                  ))}
                </div>

                <div className="border-t pt-4 space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>₹{formatINR(priceINR)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tax (10%):</span>
                    <span>₹{formatINR(taxINR)}</span>
                  </div>
                  <div className="flex justify-between text-green-600">
                    <span>Shipping:</span>
                    <span>FREE</span>
                  </div>
                  <div className="border-t pt-2 flex justify-between font-bold text-lg">
                    <span>Total:</span>
                    <span className="text-blue-600">₹{formatINR(totalINR)}</span>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mt-4">
                  <p className="text-xs text-blue-800 mb-2">
                    ✓ Secure checkout
                  </p>
                  <p className="text-xs text-blue-800">
                    ✓ Easy returns within 30 days
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}