import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Review, initialReviews } from '../data/reviews';

interface ReviewContextType {
  reviews: Review[];
  addReview: (bookId: string, userName: string, rating: number, title: string, comment: string) => void;
  getBookReviews: (bookId: string) => Review[];
  getAverageRating: (bookId: string) => number;
  getReviewCount: (bookId: string) => number;
  markHelpful: (reviewId: string) => void;
}

const ReviewContext = createContext<ReviewContextType | undefined>(undefined);

export function ReviewProvider({ children }: { children: ReactNode }) {
  const [reviews, setReviews] = useState<Review[]>([]);

  useEffect(() => {
    const savedReviews = localStorage.getItem('bookshop_reviews');
    if (savedReviews) {
      setReviews(JSON.parse(savedReviews));
    } else {
      setReviews(initialReviews);
      localStorage.setItem('bookshop_reviews', JSON.stringify(initialReviews));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('bookshop_reviews', JSON.stringify(reviews));
  }, [reviews]);

  const addReview = (
    bookId: string,
    userName: string,
    rating: number,
    title: string,
    comment: string
  ) => {
    const newReview: Review = {
      id: `review-${Date.now()}`,
      bookId,
      userName,
      rating,
      title,
      comment,
      date: new Date().toISOString().split('T')[0],
      helpful: 0,
    };
    setReviews(prev => [newReview, ...prev]);
  };

  const getBookReviews = (bookId: string) => {
    return reviews.filter(review => review.bookId === bookId).sort((a, b) => b.helpful - a.helpful);
  };

  const getAverageRating = (bookId: string) => {
    const bookReviews = getBookReviews(bookId);
    if (bookReviews.length === 0) return 0;
    const sum = bookReviews.reduce((acc, review) => acc + review.rating, 0);
    return Math.round((sum / bookReviews.length) * 10) / 10;
  };

  const getReviewCount = (bookId: string) => {
    return getBookReviews(bookId).length;
  };

  const markHelpful = (reviewId: string) => {
    setReviews(prev =>
      prev.map(review =>
        review.id === reviewId
          ? { ...review, helpful: review.helpful + 1 }
          : review
      )
    );
  };

  return (
    <ReviewContext.Provider
      value={{
        reviews,
        addReview,
        getBookReviews,
        getAverageRating,
        getReviewCount,
        markHelpful,
      }}
    >
      {children}
    </ReviewContext.Provider>
  );
}

export function useReview() {
  const context = useContext(ReviewContext);
  if (context === undefined) {
    throw new Error('useReview must be used within a ReviewProvider');
  }
  return context;
}