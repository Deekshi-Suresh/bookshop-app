import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Book } from '../data/books';

export interface WishlistItem {
  book: Book;
  addedAt: string;
}

interface WishlistContextType {
  wishlistItems: WishlistItem[];
  addToWishlist: (book: Book) => void;
  removeFromWishlist: (bookId: string) => void;
  isInWishlist: (bookId: string) => boolean;
  clearWishlist: () => void;
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export function WishlistProvider({ children }: { children: ReactNode }) {
  const [wishlistItems, setWishlistItems] = useState<WishlistItem[]>([]);

  // Load wishlist from localStorage on mount
  useEffect(() => {
    const savedWishlist = localStorage.getItem('bookshop_wishlist');
    if (savedWishlist) {
      setWishlistItems(JSON.parse(savedWishlist));
    }
  }, []);

  // Save wishlist to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('bookshop_wishlist', JSON.stringify(wishlistItems));
  }, [wishlistItems]);

  const addToWishlist = (book: Book) => {
    setWishlistItems((prevItems) => {
      if (prevItems.some((item) => item.book.id === book.id)) {
        return prevItems;
      }
      return [
        ...prevItems,
        {
          book,
          addedAt: new Date().toLocaleDateString(),
        },
      ];
    });
  };

  const removeFromWishlist = (bookId: string) => {
    setWishlistItems((prevItems) =>
      prevItems.filter((item) => item.book.id !== bookId)
    );
  };

  const isInWishlist = (bookId: string) => {
    return wishlistItems.some((item) => item.book.id === bookId);
  };

  const clearWishlist = () => {
    setWishlistItems([]);
  };

  return (
    <WishlistContext.Provider
      value={{
        wishlistItems,
        addToWishlist,
        removeFromWishlist,
        isInWishlist,
        clearWishlist,
      }}
    >
      {children}
    </WishlistContext.Provider>
  );
}

export function useWishlist() {
  const context = useContext(WishlistContext);
  if (context === undefined) {
    throw new Error('useWishlist must be used within a WishlistProvider');
  }
  return context;
}