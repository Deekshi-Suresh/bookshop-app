export function formatINR(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
  }).format(amount);
}

export function convertToINR(usdAmount: number): number {
  // Exchange rate: 1 USD = 83 INR (approximate)
  const exchangeRate = 83;
  return Math.round(usdAmount * exchangeRate);
}