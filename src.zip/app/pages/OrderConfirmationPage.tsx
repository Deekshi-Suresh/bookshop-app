import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router';
import { CheckCircle, Package, Home } from 'lucide-react';
import { Header } from '../components/Header';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';

export function OrderConfirmationPage() {
  const location = useLocation();
  const orderId = location.state?.orderId;
  const [order, setOrder] = useState<any>(null);

  useEffect(() => {
    if (orderId) {
      const orders = JSON.parse(localStorage.getItem('bookshop_orders') || '[]');
      const foundOrder = orders.find((o: any) => o.id === orderId);
      setOrder(foundOrder);
    }
  }, [orderId]);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-16">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <CheckCircle className="h-20 w-20 text-green-500" />
            </div>
            <h1 className="text-3xl font-bold mb-2">Order Confirmed!</h1>
            <p className="text-gray-600">
              Thank you for your purchase. Your order has been successfully placed.
            </p>
          </div>

          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="flex items-start gap-4 mb-6">
                <Package className="h-6 w-6 text-blue-600 mt-1" />
                <div className="flex-1">
                  <h2 className="font-semibold text-lg mb-1">Order Details</h2>
                  <p className="text-sm text-gray-600">Order ID: #{orderId}</p>
                  {order && (
                    <p className="text-sm text-gray-600">
                      Order Date: {new Date(order.date).toLocaleDateString()}
                    </p>
                  )}
                </div>
              </div>

              {order && (
                <>
                  <div className="space-y-3 mb-6">
                    {order.items.map((item: any) => (
                      <div key={item.book.id} className="flex gap-4 pb-3 border-b last:border-b-0">
                        <img
                          src={item.book.image}
                          alt={item.book.title}
                          className="w-16 h-20 object-cover rounded"
                        />
                        <div className="flex-1">
                          <h3 className="font-medium">{item.book.title}</h3>
                          <p className="text-sm text-gray-600">{item.book.author}</p>
                          <p className="text-sm">Quantity: {item.quantity}</p>
                        </div>
                        <p className="font-medium">₹{(item.book.price * item.quantity).toFixed(2)}</p>
                      </div>
                    ))}
                  </div>

                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-600">Subtotal</span>
                      <span>₹{(order.total / 1.1).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-600">Tax</span>
                      <span>₹{(order.total - order.total / 1.1).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-600">Shipping</span>
                      <span className="text-green-600">Free</span>
                    </div>
                    <div className="border-t pt-2 mt-2">
                      <div className="flex justify-between font-bold text-lg">
                        <span>Total</span>
                        <span className="text-blue-600">₹{order.total.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                    <h3 className="font-semibold mb-2">Shipping Information</h3>
                    <p className="text-sm text-gray-700">{order.customerInfo.fullName}</p>
                    <p className="text-sm text-gray-700">{order.customerInfo.address}</p>
                    <p className="text-sm text-gray-700">
                      {order.customerInfo.city}, {order.customerInfo.zipCode}
                    </p>
                    <p className="text-sm text-gray-700">{order.customerInfo.email}</p>
                    <p className="text-sm text-gray-700">{order.customerInfo.phone}</p>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <div className="flex gap-4 justify-center">
            <Link to="/dashboard">
              <Button size="lg">
                <Home className="h-4 w-4 mr-2" />
                Continue Shopping
              </Button>
            </Link>
          </div>

          <div className="mt-8 text-center">
            <p className="text-sm text-gray-600">
              A confirmation email has been sent to your email address.
            </p>
            <p className="text-sm text-gray-600">
              Your order will be delivered within 5-7 business days.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
