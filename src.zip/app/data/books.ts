export interface Book {
  id: string;
  title: string;
  author: string;
  price: number;
  category: string;
  description: string;
  image: string;
  rating: number;
  inStock: boolean;
}

export const books: Book[] = [
  {
    id: '1',
    title: 'Pride and Prejudice',
    author: 'Jane Austen',
    price: 1244,
    category: 'Classic Literature',
    description: 'A timeless classic exploring love, class, and society in Regency England.',
    image: 'https://images.unsplash.com/photo-1763768861268-cb6b54173dbf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGFzc2ljJTIwbGl0ZXJhdHVyZSUyMGJvb2slMjBjb3ZlcnxlbnwxfHx8fDE3NzE2NjQzNDh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.8,
    inStock: true
  },
  {
    id: '2',
    title: 'The Great Gatsby',
    author: 'F. Scott Fitzgerald',
    price: 1078,
    category: 'Fiction',
    description: 'A portrait of the Jazz Age in all its decadence and excess.',
    image: 'https://images.unsplash.com/photo-1771351521808-84fe6b0f93b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaWN0aW9uJTIwbm92ZWwlMjBoYXJkY292ZXJ8ZW58MXx8fHwxNzcxNjY0MzQ4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.7,
    inStock: true
  },
  {
    id: '3',
    title: 'The Silent Patient',
    author: 'Alex Michaelides',
    price: 1410,
    category: 'Mystery & Thriller',
    description: 'A gripping psychological thriller about a woman who shoots her husband and never speaks again.',
    image: 'https://images.unsplash.com/photo-1698956483970-a47edef29331?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxteXN0ZXJ5JTIwdGhyaWxsZXIlMjBib29rfGVufDF8fHx8MTc3MTY0NjcyNHww&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.6,
    inStock: true
  },
  {
    id: '4',
    title: 'Dune',
    author: 'Frank Herbert',
    price: 1576,
    category: 'Science Fiction',
    description: 'An epic tale of politics, religion, and ecology on the desert planet Arrakis.',
    image: 'https://images.unsplash.com/photo-1554357395-dbdc356ca5da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY2llbmNlJTIwZmljdGlvbiUyMGJvb2t8ZW58MXx8fHwxNzcxNjQ2NzI0fDA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.9,
    inStock: true
  },
  {
    id: '5',
    title: 'The Hobbit',
    author: 'J.R.R. Tolkien',
    price: 1327,
    category: 'Fantasy',
    description: 'Follow Bilbo Baggins on an unexpected journey through Middle-earth.',
    image: 'https://images.unsplash.com/photo-1711185892790-4cabb6701cb8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwbm92ZWwlMjBjb3ZlcnxlbnwxfHx8fDE3NzE1OTc3MjF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.8,
    inStock: true
  },
  {
    id: '6',
    title: 'The Notebook',
    author: 'Nicholas Sparks',
    price: 1161,
    category: 'Romance',
    description: 'A beautiful love story that spans decades and captures the heart.',
    image: 'https://images.unsplash.com/photo-1735805819333-19bed84b654e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb21hbmNlJTIwbm92ZWwlMjBib29rfGVufDF8fHx8MTc3MTY2NDM1MHww&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.5,
    inStock: true
  },
  {
    id: '7',
    title: 'Sapiens',
    author: 'Yuval Noah Harari',
    price: 1659,
    category: 'Non-Fiction',
    description: 'A brief history of humankind from the Stone Age to the modern era.',
    image: 'https://images.unsplash.com/photo-1711185895262-f14ad4d4eeac?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxub24lMjBmaWN0aW9uJTIwYm9vayUyMGNvdmVyfGVufDF8fHx8MTc3MTY1NjAzN3ww&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.7,
    inStock: true
  },
  {
    id: '8',
    title: 'Atomic Habits',
    author: 'James Clear',
    price: 1493,
    category: 'Self-Help',
    description: 'An easy and proven way to build good habits and break bad ones.',
    image: 'https://images.unsplash.com/photo-1619646286047-c6681c24a695?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHNlbGYlMjBoZWxwJTIwYm9va3xlbnwxfHx8fDE3NzE2NjQzNTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.9,
    inStock: true
  },
  {
    id: '9',
    title: 'Milk and Honey',
    author: 'Rupi Kaur',
    price: 995,
    category: 'Poetry',
    description: 'A collection of poetry and prose about survival, femininity, and love.',
    image: 'https://images.unsplash.com/photo-1585055462747-0bbcbd0e2167?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb2V0cnklMjBsaXRlcmF0dXJlJTIwYm9va3xlbnwxfHx8fDE3NzE1OTQ1Nzd8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.4,
    inStock: true
  },
  {
    id: '10',
    title: 'Educated',
    author: 'Tara Westover',
    price: 1410,
    category: 'Biography & Memoir',
    description: 'A memoir about a young woman who leaves her survivalist family to pursue education.',
    image: 'https://images.unsplash.com/photo-1762275193981-6fcbd5343c88?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaW9ncmFwaHklMjBtZW1vaXIlMjBib29rfGVufDF8fHx8MTc3MTY2NDM1MXww&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.8,
    inStock: true
  },
  {
    id: '11',
    title: 'The Silk Roads',
    author: 'Peter Frankopan',
    price: 1742,
    category: 'History',
    description: 'A new history of the world, told through the lens of the ancient trade routes.',
    image: 'https://images.unsplash.com/photo-1769963121626-7f1885db412c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaXN0b3J5JTIwYm9vayUyMGhhcmRjb3ZlcnxlbnwxfHx8fDE3NzE2NjQzNTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.6,
    inStock: true
  },
  {
    id: '12',
    title: 'Meditations',
    author: 'Marcus Aurelius',
    price: 1161,
    category: 'Philosophy',
    description: 'The personal writings of the Roman Emperor, offering stoic wisdom and guidance.',
    image: 'https://images.unsplash.com/photo-1769729829047-7005ae8a5c8a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaGlsb3NvcGh5JTIwYm9vayUyMGNvdmVyfGVufDF8fHx8MTc3MTY2NDM1MXww&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.7,
    inStock: true
  },
  {
    id: '13',
    title: 'Salt, Fat, Acid, Heat',
    author: 'Samin Nosrat',
    price: 1908,
    category: 'Cooking',
    description: 'Master the four elements of good cooking to transform your culinary skills.',
    image: 'https://images.unsplash.com/photo-1590587754541-a3a4f2e0d06f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb29raW5nJTIwcmVjaXBlJTIwYm9va3xlbnwxfHx8fDE3NzE1ODI2Mzl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.8,
    inStock: true
  },
  {
    id: '14',
    title: 'Into the Wild',
    author: 'Jon Krakauer',
    price: 1244,
    category: 'Travel & Adventure',
    description: 'The true story of Christopher McCandless and his journey into the Alaskan wilderness.',
    image: 'https://images.unsplash.com/photo-1503221043305-f7498f8b7888?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmF2ZWwlMjBhZHZlbnR1cmUlMjBib29rfGVufDF8fHx8MTc3MTU4NDU3NXww&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.5,
    inStock: true
  },
  {
    id: '15',
    title: 'Where the Wild Things Are',
    author: 'Maurice Sendak',
    price: 829,
    category: 'Children',
    description: 'A beloved children\'s classic about a boy\'s imaginative adventure.',
    image: 'https://images.unsplash.com/photo-1600804010026-8387cc05e1c4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlsZHJlbiUyMGtpZHMlMjBib29rfGVufDF8fHx8MTc3MTY2NDM1NXww&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.9,
    inStock: true
  },
  {
    id: '16',
    title: 'The Hunger Games',
    author: 'Suzanne Collins',
    price: 1327,
    category: 'Young Adult',
    description: 'A dystopian adventure where teens fight for survival in a televised competition.',
    image: 'https://images.unsplash.com/photo-1711185900806-bf85e7fe7767?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMGFkdWx0JTIwYm9va3xlbnwxfHx8fDE3NzE2NjQzNTV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.7,
    inStock: true
  },
  {
    id: '17',
    title: 'It',
    author: 'Stephen King',
    price: 1493,
    category: 'Horror',
    description: 'A terrifying tale of seven friends who confront an ancient evil in their hometown.',
    image: 'https://images.unsplash.com/photo-1706469980815-e2c54ace4560?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3Jyb3IlMjBzY2FyeSUyMGJvb2t8ZW58MXx8fHwxNzcxNjY0MzU0fDA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.6,
    inStock: true
  },
  {
    id: '18',
    title: 'Watchmen',
    author: 'Alan Moore',
    price: 1659,
    category: 'Graphic Novel',
    description: 'A groundbreaking graphic novel that redefined the superhero genre.',
    image: 'https://images.unsplash.com/photo-1711035964805-b71d85ee3ed2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmFwaGljJTIwbm92ZWwlMjBjb21pY3xlbnwxfHx8fDE3NzE1OTQ1Nzl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.8,
    inStock: true
  },
  {
    id: '19',
    title: 'Thinking, Fast and Slow',
    author: 'Daniel Kahneman',
    price: 1576,
    category: 'Psychology',
    description: 'Explore the two systems that drive the way we think and make decisions.',
    image: 'https://images.unsplash.com/photo-1762515376119-63e3a0dfdece?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwc3ljaG9sb2d5JTIwbWluZCUyMGJvb2t8ZW58MXx8fHwxNzcxNTg0NTc2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.7,
    inStock: true
  },
  {
    id: '20',
    title: 'A Brief History of Time',
    author: 'Stephen Hawking',
    price: 1410,
    category: 'Science',
    description: 'From the Big Bang to black holes, explore the nature of time and the universe.',
    image: 'https://images.unsplash.com/photo-1658647116052-228ce76764dc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY2llbmNlJTIwbmF0dXJlJTIwYm9va3xlbnwxfHx8fDE3NzE2NjQzNTV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.6,
    inStock: true
  },
  {
    id: '21',
    title: '1984',
    author: 'George Orwell',
    price: 1161,
    category: 'Classic Literature',
    description: 'A dystopian masterpiece about totalitarianism and surveillance.',
    image: 'https://images.unsplash.com/photo-1763768861268-cb6b54173dbf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGFzc2ljJTIwbGl0ZXJhdHVyZSUyMGJvb2slMjBjb3ZlcnxlbnwxfHx8fDE3NzE2NjQzNDh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.8,
    inStock: true
  },
  {
    id: '22',
    title: 'The Alchemist',
    author: 'Paulo Coelho',
    price: 1244,
    category: 'Fiction',
    description: 'A magical tale about following your dreams and finding your destiny.',
    image: 'https://images.unsplash.com/photo-1771351521808-84fe6b0f93b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaWN0aW9uJTIwbm92ZWwlMjBoYXJkY292ZXJ8ZW58MXx8fHwxNzcxNjY0MzQ4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.5,
    inStock: true
  },
  {
    id: '23',
    title: 'Gone Girl',
    author: 'Gillian Flynn',
    price: 1327,
    category: 'Mystery & Thriller',
    description: 'A twisted psychological thriller about a marriage gone terribly wrong.',
    image: 'https://images.unsplash.com/photo-1698956483970-a47edef29331?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxteXN0ZXJ5JTIwdGhyaWxsZXIlMjBib29rfGVufDF8fHx8MTc3MTY0NjcyNHww&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.3,
    inStock: true
  },
  {
    id: '24',
    title: 'The Martian',
    author: 'Andy Weir',
    price: 1410,
    category: 'Science Fiction',
    description: 'An astronaut fights for survival after being stranded on Mars.',
    image: 'https://images.unsplash.com/photo-1554357395-dbdc356ca5da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY2llbmNlJTIwZmljdGlvbiUyMGJvb2t8ZW58MXx8fHwxNzcxNjQ2NzI0fDA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.7,
    inStock: true
  },
  {
    id: '25',
    title: 'Harry Potter and the Sorcerer\'s Stone',
    author: 'J.K. Rowling',
    price: 1078,
    category: 'Fantasy',
    description: 'The beginning of the magical journey of the boy who lived.',
    image: 'https://images.unsplash.com/photo-1711185892790-4cabb6701cb8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwbm92ZWwlMjBjb3ZlcnxlbnwxfHx8fDE3NzE1OTc3MjF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.9,
    inStock: true
  }
];

export const categories = [
  'All',
  'Classic Literature',
  'Fiction',
  'Mystery & Thriller',
  'Science Fiction',
  'Fantasy',
  'Romance',
  'Non-Fiction',
  'Self-Help',
  'Poetry',
  'Biography & Memoir',
  'History',
  'Philosophy',
  'Cooking',
  'Travel & Adventure',
  'Children',
  'Young Adult',
  'Horror',
  'Graphic Novel',
  'Psychology',
  'Science'
];
